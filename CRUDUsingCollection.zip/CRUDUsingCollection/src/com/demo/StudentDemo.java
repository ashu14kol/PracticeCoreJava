package com.demo;

import java.util.Scanner;

public class StudentDemo {

	public static void main(String[] args) {

		int option = 0;
		System.out.println("***********WELCOME TO STUDENT PORTAL***********");
		Scanner sc = new Scanner(System.in);
		do {
			System.out.println("Please choose option : ");

			System.out.println("1. Insert Student");
			System.out.println("2. Delete Student");
			System.out.println("3. Update Student");
			System.out.println("4. Search Student");
			System.out.println("5. View all student details");
			System.out.println("6. Exit");
			System.out.print("Your option is ? ");
			option = sc.nextInt();
			getOptionFromUSer(option);

		} while (option != 6);
	}

	public static void getOptionFromUSer(int option) {
		Scanner sc = new Scanner(System.in);

		System.out.println("Selected option is : " + option);
		StudentService service = new StudentService();

		switch (option) {
		case 1:
			System.out.println("TO Insert Student");
			service.InsertStudent();
			break;

		case 2:
			System.out.println("TO Delete Student");
			System.out.print("Enter roll number :");
			service.DeleteStudent(sc.nextInt());

			break;

		case 3:
			System.out.println("TO Update Student");
			System.out.print("Enter roll number :");
			service.UpdateStudent(sc.nextInt());
			break;

		case 4:
			System.out.println("TO Search Student");
			System.out.print("Enter roll number :");
			service.SearchStudentData(sc.nextInt());
			System.out.println("Successfully searched!!!");

			break;

		case 5:
			System.out.println("Here are the details of all students");
			service.viewAllStudentsDetails();
			break;

		case 6:
			System.out.println("BYE BYE");
			break;

		default:
			System.out.println("THANK YOU FOR USING OUR PORTAL!!");
			break;

		}

	}

}
