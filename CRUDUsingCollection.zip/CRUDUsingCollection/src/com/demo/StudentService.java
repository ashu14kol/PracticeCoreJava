package com.demo;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

import com.demo.model.Student;

public class StudentService {
	static List<Student> listOfStudents = new ArrayList<>();
	Scanner sc = new Scanner(System.in);

	public void InsertStudent() {
		List<String> technologies = new ArrayList<>();
		Student s1 = new Student();
		System.out.println("Enter student details ");
		System.out.print("Enter roll number : ");
		s1.setRollNo(sc.nextInt());
		System.out.print("Enter name : ");
		s1.setName(sc.next());
		System.out.print("Enter city : ");
		s1.setCity(sc.next());
		System.out.print("Enter Date of joining (MM/DD/YYYY format): ");
		String doj = sc.next();
		Date startDate;
		try {
			DateFormat df = new SimpleDateFormat("MM/dd/yyyy");
			startDate = df.parse(doj);
			s1.setDateOfJoining(startDate);

		} catch (ParseException e) {
			e.printStackTrace();
		}
		System.out.println("Enter number of technologies you know ? ");
		int no = sc.nextInt();
		for (int i = 0; i < no; i++) {
			System.out.print("Enter Technology" + (i + 1) + ":");
			technologies.add(i, sc.next());
		}
		s1.setTechnologies(technologies);
		listOfStudents.add(s1);
		System.out.println("successfully inserted");
	}

	public void DeleteStudent(int rollNo) {

		Iterator<Student> iter = listOfStudents.iterator();
		while (iter.hasNext()) {
			Student str = iter.next();

			if (str.getRollNo() == rollNo)
				iter.remove();
			else
				System.out.println("Record with givent roll number does not exists");

		}
	}

	public void UpdateStudent(int rollNo) {
		List<String> technologies = new ArrayList<>();

		for (Student student : listOfStudents) {
			if (student.getRollNo() == rollNo) {
				System.out.println("Enter new values to set");
				System.out.print("Enter name : ");
				student.setName(sc.next());
				System.out.print("Enter city : ");
				student.setCity(sc.next());
				System.out.print("Enter Date of joining (MM/DD/YYYY format): ");
				String doj = sc.next();
				Date startDate;
				try {
					DateFormat df = new SimpleDateFormat("MM/dd/yyyy");
					startDate = df.parse(doj);
					student.setDateOfJoining(startDate);

				} catch (ParseException e) {
					e.printStackTrace();
				}
				System.out.println("Enter number of technologies you know ? ");
				int no = sc.nextInt();
				for (int i = 0; i < no; i++) {
					System.out.print("Enter Technology" + (i + 1) + ":");
					technologies.add(i, sc.next());
				}
				student.setTechnologies(technologies);
				System.out.println("Successfully updated!!!");

			} else
				System.out.println("Record with givent roll number does not exists");
		}
	}

	public void SearchStudentData(int rollNo) {
		for (Student student : listOfStudents) {
			if (student.getRollNo() == rollNo) {
				System.out.println(student.getRollNo());
				System.out.println(student.getName());
				System.out.println(student.getCity());
				System.out.println(student.getDateOfJoining());
				List<String> techs = new ArrayList<>();
				techs = student.getTechnologies();
				for (String tech : techs) {
					System.out.println(" Technology : " + tech);
				}
				System.out.println("Successfully searched!!!");

			} else
				System.out.println("Record with givent roll number does not exists");

		}
	}

	public void viewAllStudentsDetails() {
		for (Student student : listOfStudents) {
			System.out.println("Roll no : " + student.getRollNo() + "\n Name : " + student.getName() + "\n City : "
					+ student.getCity() + "\n Date of Joining : " + student.getDateOfJoining());
			List<String> techs = new ArrayList<>();
			techs = student.getTechnologies();
			for (String tech : techs) {
				System.out.println(" Technology : " + tech);
			}
		}
	}

}
